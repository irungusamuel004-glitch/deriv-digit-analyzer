# Deriv Digit Analyzer — analysis-only responsive website

## Features
- Responsive dashboard for phone and laptop
- Public Deriv WebSocket tick subscription
- Last-digit frequency table and chart
- Matches: adjacent ticks whose final digit is the same
- Even/Odd and Over/Under observed frequencies
- Rise/Fall tick movement statistics
- Simple descriptive signal rules with configurable sample minimum
- Recent tick table
- No trade execution, no API token input, and no credential storage

## Setup
1. Download and extract `deriv_digit_analyzer.zip`.
2. Open `index.html` in a modern browser with an internet connection.
3. Choose a listed symbol and select **Connect live**.
4. If your browser blocks WebSockets from a local file, open a terminal in this folder and run:
   `python -m http.server 8000`
   Then browse to `http://localhost:8000`.

## Data and assumptions
- The page connects to the public market-data endpoint configured in `index.html`. Deriv API endpoint/version availability can change; consult https://developers.deriv.com/ if connection fails.
- The starter market list is not dynamically fetched. Confirm symbol availability against the current Deriv API.
- Last digit is derived from quote precision (`pip_size`). Verify the appropriate digit convention for each contract before using it for contract-level research.
- Over means last digit strictly greater than the threshold; Under means strictly less. The digit equal to the threshold belongs to neither group.
- Matches is the share of adjacent tick pairs with equal last digits. This is a descriptive definition, not a Deriv contract payout result.
- Signals are sample summaries only, not a forecast, financial advice, or evidence of a profitable strategy.
- Ticks are kept in memory and cleared on page reload. This starter does not persist personal data.

## Security
- Never enter your Deriv password, session cookies, or API token into this page.
- Public tick data does not require an account token.
- The page never places orders and has no trading endpoint.
- For public deployment, host over HTTPS, maintain a strict Content Security Policy, keep dependencies minimal, and check the official API documentation before upgrades.

Official documentation: https://developers.deriv.com/
